vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Jun 2008 12:59:30 -0000
vti_extenderversion:SR|4.0.2.8912
