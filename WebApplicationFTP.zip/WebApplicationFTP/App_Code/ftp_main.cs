using System;
using FTPLib;
using System.Text.RegularExpressions;

namespace ftp
{
	public class ftp_main
	{
        public static FTP ftplib = new FTP();
	}
}