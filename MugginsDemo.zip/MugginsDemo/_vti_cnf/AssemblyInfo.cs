vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 May 2008 08:54:10 -0000
vti_extenderversion:SR|4.0.2.8912
