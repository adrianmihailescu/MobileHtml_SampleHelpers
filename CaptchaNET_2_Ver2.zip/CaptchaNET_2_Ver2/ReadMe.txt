To use this files in VS 2005, create a new Web site. Then, replace Web site files with these files.

Web site files are in DriveName\Documents and Settings\[Username]\My Documents\Visual Studio 2005\WebSites\[Web site name] by default (Windows XP)